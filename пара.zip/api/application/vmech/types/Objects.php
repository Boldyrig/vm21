<?php

require_once('BaseElement.php');

class Objects extends BaseElement {}