<?php

require_once('BaseElement.php');

class Tank extends BaseElement {}