<?php

require_once('BaseElement.php');

class Building extends BaseElement {}