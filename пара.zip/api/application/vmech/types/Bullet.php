<?php

require_once('BaseElement.php');

class Bullet extends BaseElement {}