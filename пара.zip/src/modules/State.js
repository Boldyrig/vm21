export default class State {
    login = null;
    money = 0;
    isRegistr = false;
}